var searchData=
[
  ['id_5fprocesador_0',['id_procesador',['../classProcesador.html#ae05c442efbe50ce6cfe5d02c7dc4a1f3',1,'Procesador']]],
  ['id_5fproceso_1',['id_proceso',['../classProceso.html#a05023cae2b605079ec2277a37d8a914e',1,'Proceso::id_proceso()'],['../structProcess__Area_1_1priority.html#a594eff29bc0744ac163ad1aa1b10a1bc',1,'Process_Area::priority::id_proceso()']]]
];
