var searchData=
[
  ['npc_0',['npc',['../structProcess__Area_1_1priority.html#a6c32d5c64513965c094223f0a3904904',1,'Process_Area::priority']]],
  ['npr_1',['npr',['../structProcess__Area_1_1priority.html#a62ac409bb4f0f77b4ba1c1adda0e2c1e',1,'Process_Area::priority']]]
];
