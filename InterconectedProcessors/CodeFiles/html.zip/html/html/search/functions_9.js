var searchData=
[
  ['procesador_0',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()'],['../classProcesador.html#a440c2613bf09527f2cdecbcffcda5437',1,'Procesador::Procesador(string &amp;id, const int &amp;m)']]],
  ['proceso_1',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso::Proceso()'],['../classProceso.html#af3046f74874a40f27d295c9f26381e67',1,'Proceso::Proceso(const int &amp;id_proceso, const int &amp;tiempo, const int &amp;memoria_ocupada)']]],
  ['process_5farea_2',['Process_Area',['../classProcess__Area.html#af5dfe376d9e276e47f48109c395fb2e2',1,'Process_Area']]],
  ['puedo_5fenviar_5fproceso_5fcluster_3',['puedo_enviar_proceso_cluster',['../classCluster.html#a6f390ff9d7c49c7eb72ec23c33f551ee',1,'Cluster']]]
];
