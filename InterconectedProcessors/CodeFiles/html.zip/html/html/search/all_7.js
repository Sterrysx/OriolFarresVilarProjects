var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mapa_5fdonde_5festa_5fproceso_1',['mapa_donde_esta_proceso',['../classProcesador.html#acc23d3f51001b3f337e52e55c3ab91ac',1,'Procesador']]],
  ['mapa_5fint_5fproceso_2',['mapa_int_proceso',['../classProcesador.html#a155da8e2a69cc1fb7dc41392f9f9b04c',1,'Procesador']]],
  ['mapa_5fsize_5fposition_3',['mapa_size_position',['../classProcesador.html#a87f5bf23b2a1618145fc18d5f0eed0f6',1,'Procesador']]],
  ['mapa_5fstring_5fpriority_4',['mapa_string_priority',['../classProcess__Area.html#a01c21413e85d8e8a226bfa9c9b218071',1,'Process_Area']]],
  ['mapa_5fstring_5fprocesador_5',['mapa_string_procesador',['../classCluster.html#a4a04c5b2ccd39cadd89a2a9b3a910294',1,'Cluster']]],
  ['memoria_5fdisponible_6',['memoria_disponible',['../classProcesador.html#a4bf224cfb5ccd78bc050ee2772f69af3',1,'Procesador']]],
  ['memoria_5ftotal_7',['memoria_total',['../classProcesador.html#af9b292cca407f6ffe2605bbf54551dd8',1,'Procesador']]],
  ['metodo_5fhueco_5fderecha_8',['metodo_hueco_derecha',['../classProcesador.html#ad2cf8a51a0e163f00b098132b53e90eb',1,'Procesador']]],
  ['metodo_5fhueco_5fizquierda_9',['metodo_hueco_izquierda',['../classProcesador.html#ade4e7f24648735945ffa647cd50f9768',1,'Procesador']]],
  ['modificar_5fbintree_10',['modificar_bintree',['../classCluster.html#aa4185c031619dd9448fa3efd7887a363',1,'Cluster']]],
  ['modificar_5fcluster_11',['modificar_cluster',['../classCluster.html#a32ff3a98bbaafc85f05328adbdd3d0c4',1,'Cluster']]],
  ['modificar_5ftiempo_12',['modificar_tiempo',['../classProceso.html#a4233cb9b5cd128e29430c54bbd16fe0f',1,'Proceso']]]
];
