var searchData=
[
  ['simulacion_20del_20funcionamiento_20de_20una_20arquitectura_20multiprocesador_2c_20donde_20cada_20procesador_20trabaja_20exclusivamente_20con_20su_20propia_20memoria_20y_20puede_20ejecutar_20más_20de_20un_20proceso_20simultáneamente_2e_0',['Simulacion del funcionamiento de una arquitectura multiprocesador, donde cada procesador trabaja exclusivamente con su propia memoria y puede ejecutar más de un proceso simultáneamente.',['../index.html',1,'']]]
];
