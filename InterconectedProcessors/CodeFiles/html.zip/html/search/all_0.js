var searchData=
[
  ['add_5fprocesadores_0',['add_procesadores',['../classCluster.html#a53e1ab464484ce784b511fccb2c3eb7c',1,'Cluster']]],
  ['alta_5fprioridad_1',['alta_prioridad',['../classProcess__Area.html#a7aca62499c6438026361b21101625d2f',1,'Process_Area']]],
  ['alta_5fproceso_5fespera_2',['alta_proceso_espera',['../classProcess__Area.html#aa2a6f0f9721365d84eff097fc85a5014',1,'Process_Area']]],
  ['alta_5fproceso_5fprocesador_3',['alta_proceso_procesador',['../classCluster.html#ad865a6b325e4b5b517554c15b8312f13',1,'Cluster']]],
  ['anadir_5fprioridad_5fa_5farea_5fespera_4',['anadir_prioridad_a_area_espera',['../classProcess__Area.html#afb281e550033d513249d202072c24eef',1,'Process_Area']]],
  ['arbol_5',['arbol',['../classCluster.html#aa9ae4d95f9c207141e9e63bb1c7f4f85',1,'Cluster']]],
  ['avanzar_5ftiempo_6',['avanzar_tiempo',['../classCluster.html#a081bf3aef86f0e4d3a2fe1617e673a19',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#a65886db81ff9d7cb1da9e4d7193742cf',1,'Procesador::avanzar_tiempo()']]]
];
