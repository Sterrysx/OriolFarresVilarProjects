var searchData=
[
  ['hay_5fespacio_0',['hay_espacio',['../classProcesador.html#a35b3a805dac6602438604eb49f5de934',1,'Procesador']]],
  ['hay_5fmas_5fprocesos_5fderecha_1',['hay_mas_procesos_derecha',['../classProcesador.html#a6c30f3f0d1e1556dbee1644defe28d37',1,'Procesador']]],
  ['hay_5fmas_5fprocesos_5fizquierda_2',['hay_mas_procesos_izquierda',['../classProcesador.html#a202972afefe91bfe06f9889d6bc14b0e',1,'Procesador']]],
  ['hueco_5fderecho_3',['hueco_derecho',['../classProcesador.html#ab258f1e548e0840548ca3e7bd04764d0',1,'Procesador']]],
  ['hueco_5fizquierdo_4',['hueco_izquierdo',['../classProcesador.html#aab58ab6b089251b687a4a00ef8550b14',1,'Procesador']]]
];
