var searchData=
[
  ['cabe_5fproceso_5fal_5fprocesador_0',['cabe_proceso_al_procesador',['../classProcesador.html#a70d94dbad6ef698f53382d3d531d28c1',1,'Procesador']]],
  ['cluster_1',['Cluster',['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster::Cluster()'],['../classCluster.html',1,'Cluster']]],
  ['cluster_2ecc_2',['Cluster.cc',['../Cluster_8cc.html',1,'']]],
  ['cluster_2ehh_3',['Cluster.hh',['../Cluster_8hh.html',1,'']]],
  ['colocar_5fproceso_4',['colocar_proceso',['../classProcesador.html#aaacca8af5cc436f687b8ebede9728b30',1,'Procesador']]],
  ['compactar_5fmemoria_5fcluster_5',['compactar_memoria_cluster',['../classCluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster']]],
  ['compactar_5fmemoria_5fprocesador_6',['compactar_memoria_procesador',['../classCluster.html#ad5a7196b5460d5c0ffcb8ff5bca48908',1,'Cluster::compactar_memoria_procesador()'],['../classProcesador.html#a6c5d44f2b2e9aee6553a77d3056626f0',1,'Procesador::compactar_memoria_procesador()']]],
  ['configurar_5fcluster_7',['configurar_cluster',['../classCluster.html#a84f9daea57e2773ab5766ef82d2a1def',1,'Cluster']]],
  ['consultar_5fhueco_5fmas_5fgrande_8',['consultar_hueco_mas_grande',['../classProcesador.html#a1a8765ab32b05c5b75bf586966a2aecf',1,'Procesador']]],
  ['consultar_5fid_9',['consultar_id',['../classProcesador.html#a3caaa26dfe5132fb7fc6b58f28c00343',1,'Procesador::consultar_id()'],['../classProceso.html#a33b52579d6ee93986d33341bacc86521',1,'Proceso::consultar_id()']]],
  ['consultar_5fmemoria_10',['consultar_memoria',['../classProcesador.html#ac54b06ae11bbccb3d5a9933c4cef0bbc',1,'Procesador::consultar_memoria()'],['../classProceso.html#a55976a19b8d909276c62e8be10036df5',1,'Proceso::consultar_memoria()']]],
  ['consultar_5fmemoria_5flibre_11',['consultar_memoria_libre',['../classProcesador.html#a6926d998ba3071e7879d38914e49edc8',1,'Procesador']]],
  ['consultar_5ftiempo_12',['consultar_tiempo',['../classProceso.html#a4816bee1b97d41126160494109f84c42',1,'Proceso']]],
  ['contiene_5fprocesos_13',['contiene_procesos',['../classProcesador.html#adf464dc9cc010a60492d62950a922e8e',1,'Procesador']]],
  ['crear_5fhueco_14',['crear_hueco',['../classProcesador.html#aca2b66b6c1ce99c909b698799bc193bd',1,'Procesador']]]
];
