var searchData=
[
  ['priority_0',['priority',['../structProcess__Area_1_1priority.html',1,'Process_Area']]],
  ['procesador_1',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_2',['Proceso',['../classProceso.html',1,'']]],
  ['process_5farea_3',['Process_Area',['../classProcess__Area.html',1,'']]]
];
