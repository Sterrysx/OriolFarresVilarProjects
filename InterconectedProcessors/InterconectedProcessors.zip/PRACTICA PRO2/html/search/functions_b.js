var searchData=
[
  ['tiene_5fproceso_0',['tiene_proceso',['../classProcesador.html#a67356b43e4e215dd4e936555443df991',1,'Procesador']]]
];
