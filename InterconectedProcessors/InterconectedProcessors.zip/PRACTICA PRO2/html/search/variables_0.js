var searchData=
[
  ['arbol_0',['arbol',['../classCluster.html#aa9ae4d95f9c207141e9e63bb1c7f4f85',1,'Cluster']]]
];
